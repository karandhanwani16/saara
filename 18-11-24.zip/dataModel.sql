-- Database Name: saara
--
-- #################
--
-- Table Name: Users
CREATE TABLE `users` (
    `user_id` bigint(20) NOT NULL,
    `user_email` varchar(300) NOT NULL,
    `user_password` varchar(300) NOT NULL,
    `user_first_name` varchar(200) NOT NULL,
    `user_last_name` varchar(200) NOT NULL,
    `user_type` varchar(200) NOT NULL,
    `user_last_login` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
    PRIMARY KEY (`user_id`)
);

-- Table Name: category
CREATE TABLE `category` (
    `category_id` bigint(20) NOT NULL,
    `category_name` varchar(500) NOT NULL,
    `category_created_by` bigint(20) NOT NULL,
    `category_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
    `category_updated_by` bigint(20) NOT NULL,
    `category_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) 
--Table Name: logs
CREATE TABLE `logs` (
    `log_timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
    `action_type` varchar(200) NOT NULL,
    `log_action` varchar(200) NOT NULL,
    `log_user` varchar(200) NOT NULL,
    `log_description` varchar(7900) NOT NULL
) 
-- Table Name: products
CREATE TABLE `products` (
 `product_id` bigint(20) NOT NULL,
 `category_id` bigint(20) NOT NULL,
 `brand_id` bigint(20) NOT NULL,
 `product_name` varchar(500) NOT NULL,
 `product_barcode` varchar(500) NOT NULL,
 `product_description` varchar(2000) NOT NULL,
 `product_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
 `product_created_by` bigint(20) NOT NULL,
 `product_updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
 `product_updated_by` bigint(20) NOT NULL
)

CREATE TABLE `product_prices` (
 `product_prices_id` bigint(20) NOT NULL,
 `product_id` bigint(20) NOT NULL,
 `product_prices_cost_price` varchar(20) NOT NULL,
 `product_prices_stock` varchar(20) NOT NULL,
 `product_prices_gst_percentage` varchar(20) NOT NULL,
 `product_prices_selling_price` varchar(20) NOT NULL,
 `product_prices_parlour_price` varchar(20) NOT NULL,
 `product_prices_batch_number` varchar(100) NOT NULL
) 
--Table Name: supplier
CREATE TABLE `supplier` (
    `supplier_id` bigint(20) NOT NULL,
    `supplier_name` varchar(500) NOT NULL,
    `supplier_location` varchar(500) NOT NULL,
    `supplier_mobile` varchar(500) NOT NULL,
    `supplier_description` varchar(500) NOT NULL,
    `supplier_created_by` bigint(20) NOT NULL,
    `supplier_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
    `supplier_updated_by` bigint(20) NOT NULL,
    `supplier_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) 

--Table Name: brand
CREATE TABLE `brand` (
    `brand_id` bigint(20) NOT NULL,
    `brand_name` varchar(500) NOT NULL,
    `brand_created_by` bigint(20) NOT NULL,
    `brand_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
    `brand_updated_by` bigint(20) NOT NULL,
    `brand_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
)

CREATE TABLE `purchase` (
 `purchase_id` bigint(20) NOT NULL,
 `supplier_id` bigint(20) NOT NULL,
 `purchase_no` varchar(100) NOT NULL,
 `purchase_date` date NOT NULL,
 `purchase_amount` varchar(100) NOT NULL,
 `purchase_signed_by` varchar(200) NOT NULL,
 `purchase_type` varchar(100) NOT NULL,
 `purchase_created_by` bigint(20) NOT NULL,
 `purchase_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
 `purchase_updated_by` bigint(20) NOT NULL,
 `purchase_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
)
CREATE TABLE `purchase_items` (
 `purchase_item_id` int(11) NOT NULL,
 `purchase_id` bigint(20) NOT NULL,
 `purchase_item_product_id` bigint(20) NOT NULL,
 `purchase_item_product_name` varchar(100) NOT NULL,
 `purchase_item_product_quantity` int(11) NOT NULL,
 `purchase_item_price_id` bigint(20) NOT NULL,
 `purchase_item_product_price` int(11) NOT NULL,
 `purchase_item_product_gst` varchar(100) NOT NULL,
 `purchase_item_product_is_igst` varchar(100) NOT NULL,
 `purchase_item_product_total` int(11) NOT NULL
)
-- Table Name: sale

CREATE TABLE `sales` (
 `sale_id` bigint(20) NOT NULL,
 `sale_date` date DEFAULT NULL,
 `sales_attended_by` varchar(100) NOT NULL,
 `customer_name` varchar(255) DEFAULT NULL,
 `customer_phone` varchar(20) DEFAULT NULL,
 `customer_email` varchar(255) DEFAULT NULL,
 `discount` varchar(20) DEFAULT NULL,
 `discount_type` varchar(20) DEFAULT NULL,
 `cash_amount` varchar(20) DEFAULT NULL,
 `upi_amount` varchar(20) DEFAULT NULL,
 `card_amount` varchar(20) NOT NULL,
 `card_charges` varchar(100) NOT NULL,
 `sale_total_before_tax` varchar(20) NOT NULL,
 `sale_sgst_amount` varchar(20) NOT NULL,
 `sale_cgst_amount` varchar(20) NOT NULL,
 `sale_igst_amount` varchar(20) NOT NULL,
 `sale_total_after_tax` varchar(20) NOT NULL,
 `sale_discount_amount` varchar(20) NOT NULL,
 `sale_final_discount_amount` varchar(20) NOT NULL,
 `sale_roundoff` varchar(20) NOT NULL,
 `sale_net_amount` varchar(20) NOT NULL,
 `sale_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
 `sale_created_by` bigint(20) NOT NULL,
 `sale_updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
 `sale_updated_by` bigint(20) NOT NULL,
 PRIMARY KEY (`sale_id`)
) 

-- Table Name: sale_items

	CREATE TABLE `sale_items` (
 `sale_item_id` bigint(20) NOT NULL,
 `sale_id` bigint(20) DEFAULT NULL,
 `product_id` bigint(20) DEFAULT NULL,
 `product_name` varchar(255) DEFAULT NULL,
 `product_price_id` bigint(20) DEFAULT NULL,
 `product_price` varchar(20) DEFAULT NULL,
 `quantity` int(11) DEFAULT NULL,
 `discount` varchar(20) DEFAULT NULL,
 `discount_type` varchar(20) DEFAULT NULL,
 `gst_percentage` varchar(20) DEFAULT NULL,
 `is_igst` varchar(20) DEFAULT NULL,
 `total` varchar(20) DEFAULT NULL,
 PRIMARY KEY (`sale_item_id`),
 KEY `sale_id` (`sale_id`),
 CONSTRAINT `sale_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`)
)

CREATE TABLE `customers` (
 `customer_id` bigint(20) NOT NULL,
 `customer_name` varchar(200) NOT NULL,
 `customer_email` varchar(100) NOT NULL,
 `customer_phone` varchar(100) NOT NULL
) 