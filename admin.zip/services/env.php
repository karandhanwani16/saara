<?php

$otpValidTime = 15;

$env = "dev";
// $env = "qa";
// $env = "prod";

$HOST = "";
$USER = "";
$PASSWORD = "";
$DATABASE = "";

if ($env == "dev") {
    $HOST = "localhost";
    $USER = "root";
    $PASSWORD = "";
    $DATABASE = "saara";
} else {
    $HOST = "";
    $USER = "";
    $PASSWORD = "";
    $DATABASE = "";
}


$backupEmail = "karandhanwani20@gmail.com";
$billingMainEmail = "";
$companyName = "Saara Gift Shop";

$sendActionsEmails = [];

//$sendActionsEmails = [];
